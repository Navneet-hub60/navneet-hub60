async function sendEmergency() {

    const patientName =
    document.getElementById("patientName").value;

     const gender =
    document.getElementById("gender").value;

     const age =
    document.getElementById("age").value;

    const roomNumber =
    document.getElementById("roomNumber").value;

    const problem =
    document.getElementById("problem").value;

     const doctor =
    document.getElementById("doctor").value;

    const status =
    document.getElementById("status");

    // TELEGRAM BOT DETAILS
    const botToken = "8963859027:AAHpXj0ODph6hMuot6upknMyXG1T4YuEcKE";
    const chatId =  "5779387102";

    const message =
`🚨 EMERGENCY ALERT  🚨

Patient Name :  ${patientName}
Gender : ${gender}
Age : ${age}
Room Number :  ${roomNumber}
Doctor Required :  ${doctor}
Emergency:  ${problem} 

Immediate assistance required!`;

    const url =
`https://api.telegram.org/bot${botToken}/sendMessage`;

    try{

        const response = await fetch(url,{
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({
                chat_id:chatId,
                text:message
            })
        });

        if(response.ok){

            status.innerHTML =
            " ✅ Alert Sent Successfully  ";

            status.style.color = "#00ffae";
            status.style.fontSize = "20px";
            status.style.fontWeight = "bold";
            

        }else{

            status.innerHTML =
            "❌ Failed To Send Alert";

            status.style.color = "red";
            status.style.fontSize = "20px";
            status.style.fontWeight = "bold";
        }

    }catch(error){

        status.innerHTML =
        "Error Occurred";

        status.style.color = "red";
    }
}